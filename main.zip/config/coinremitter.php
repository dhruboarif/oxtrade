<?php

return [
    'BTC'=>[
        'API_KEY'=>'API_KEY_FROM_WEBSITE',
        'PASSWORD'=>'PASSWORD',
    ],
    'LTC'=>[
        'API_KEY'=>'API_KEY_FROM_WEBSITE',
        'PASSWORD'=>'PASSWORD',
    ],
];
