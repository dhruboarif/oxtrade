<?php

return [
    'active' => 'default',
];
